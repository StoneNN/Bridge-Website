import styles from './gameNational.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page gameNational</h1>
    </div>
  );
}
