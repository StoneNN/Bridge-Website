import styles from './trailnotice.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page trailnotice</h1>
    </div>
  );
}
