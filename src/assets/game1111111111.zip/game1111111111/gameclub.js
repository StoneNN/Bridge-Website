import styles from './gameclub.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page gameclub</h1>
    </div>
  );
}
