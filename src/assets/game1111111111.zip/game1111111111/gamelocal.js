import styles from './gamelocal.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page gamelocal</h1>
    </div>
  );
}
