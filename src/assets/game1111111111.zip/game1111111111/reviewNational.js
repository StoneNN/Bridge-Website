import styles from './reviewNational.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page reviewNational</h1>
    </div>
  );
}
