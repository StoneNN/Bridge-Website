import styles from './game.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page game</h1>
    </div>
  );
}
