import styles from './reviewlocal.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page reviewlocal</h1>
    </div>
  );
}
