import styles from './gameseatch.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page gameseatch</h1>
    </div>
  );
}
