import styles from './review.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page review</h1>
    </div>
  );
}
