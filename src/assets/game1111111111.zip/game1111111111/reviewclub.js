import styles from './reviewclub.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page reviewclub</h1>
    </div>
  );
}
